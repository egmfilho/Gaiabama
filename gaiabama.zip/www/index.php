<?php if( $_SERVER["HTTP_HOST"] == "www.alabamaimoveis.com.br" ){ header("Location: http://www.alabamaimoveis.com.br/coming-soon/" ); die(); } ?><!DOCTYPE html><html><head><title>Gaia</title><meta name="format-detection" content="telephone=no"><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta charset="utf-8"><link rel="shortcut icon" href="./favicon.ico" type="image/x-icon"><!-- Stylesheets--><link rel="stylesheet" href="styles/vendor.min.css"><link rel="stylesheet" href="styles/futura.css"><link rel="stylesheet" href="styles/main.css"></head><body ng-app="alabama"><header3 navigation="[
				{
					&quot;nome&quot;: &quot;Home&quot;,
					&quot;url&quot;: &quot;/&quot;,
					&quot;target&quot;: &quot;&quot;
				},
				{
					&quot;nome&quot;: &quot;Sobre&quot;,
					&quot;url&quot;: &quot;/sobre&quot;,
					&quot;target&quot;: &quot;&quot;
				},
				{
					&quot;nome&quot;: &quot;Imóveis&quot;,
					&quot;url&quot;: &quot;/imoveis&quot;,
					&quot;target&quot;: &quot;&quot;
				},
				{
					&quot;nome&quot;: &quot;Mapa&quot;,
					&quot;url&quot;: &quot;/mapa&quot;,
					&quot;target&quot;: &quot;&quot;
				},
				{
					&quot;nome&quot;: &quot;Equipe&quot;,
					&quot;url&quot;: &quot;/equipe&quot;,
					&quot;target&quot;: &quot;&quot;
				},
				{
					&quot;nome&quot;: &quot;Contato&quot;,
					&quot;url&quot;: &quot;/contato&quot;,
					&quot;target&quot;: &quot;&quot;
				}
			]" whatsapp="(21) 99999-8888" tel="(21) 2222-3333" email="sac@email.com.br"></header3><div class="scroll-top hidden-xs" ng-class="{&quot;visible&quot;: scrollY &gt;= 100}" ng-click="scrollTop()"><i class="fa fa-chevron-up"></i></div><div class="container-narrow" ng-view="" autoscroll></div><div ng-include="&quot;../partials/footer.html&quot;" ng-hide="currentPath == &quot;/mapa&quot;"></div><script src="http://maps.google.com/maps/api/js?key=AIzaSyAweoS6Re-3ct3tPGEhRW94VsKY8nmZT9E"></script><script src="scripts/vendors.min.js"></script><script src="scripts/app.min.js"></script></body></html>